//
//  ChatMessageCell.swift
//  CrossChat
//
//  Created by Mahmoud Abdurrahman on 7/10/18.
//  Copyright © 2018 Crossover. All rights reserved.
//

import Foundation

import UIKit

class ChatMessageCell: UITableViewCell {
    
    @IBOutlet weak var messageLabel: UILabel!
}
