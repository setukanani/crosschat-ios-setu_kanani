//
//  ChatView.swift
//  CrossChat
//
//  Created by Mahmoud Abdurrahman on 7/11/18.
//  Copyright © 2018 Crossover. All rights reserved.
//

import Foundation

protocol ChatView: BaseView {
    func updateChatView()
}
