//
//  ContentAnalyserHashtagsTests.swift
//  CrossChatTests
//
//  Created by Setu on 23/07/18.
//  Copyright © 2018 Crossover. All rights reserved.
//

import XCTest

class ContentAnalyserHashtagsTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testHashtagAtTheBeginning() {
        let extracted = try! ContentAnalyser.extractHashtags(from: "#user hashtag")
        let expected = ["user"]
        
        XCTAssertEqual(extracted, expected, "Failed to extract hashtag at the beginning")
    }
    
    func testHashtagWithLeadingSpace() {
        let extracted = try! ContentAnalyser.extractHashtags(from: " #user hashtag")
        let expected = ["user"]
        
        XCTAssertEqual(extracted, expected, "Failed to extract hashtag with leading space")
    }
    
    func testHashtagInMidText() {
        let extracted = try! ContentAnalyser.extractHashtags(from: "hashtag #user here")
        let expected = ["user"]
        
        XCTAssertEqual(extracted, expected, "Failed to extract hashtag in mid text")
    }
    
    func testMultipleHashtags() {
        let extracted = try! ContentAnalyser.extractHashtags(from: "hashtag #user1 here and #user2 here")
        let expected = ["user1", "user2"]
        
        XCTAssertEqual(extracted, expected, "Failed to extract multiple hashtaged users")
    }
    
    func testInvalidHashtag() {
        let extracted = try! ContentAnalyser.extractHashtags(from: "# invalid hashtag.")
        let expected: [String] = []
        
        XCTAssertEqual(extracted, expected,"Extracted an invalid hashtag: \(extracted)")
    }
    
    func testHashtagWithIndices() {
        let extracted = try! ContentAnalyser.extractHashtagsWithIndices(from:" #user1 hashtag #user2 here #user3 ")
        
        XCTAssertEqual(extracted.count, 3)
        XCTAssertEqual(extracted[0].start, 1)
        XCTAssertEqual(extracted[0].end, 7)
        XCTAssertEqual(extracted[1].start, 16)
        XCTAssertEqual(extracted[1].end, 22)
        XCTAssertEqual(extracted[2].start, 28)
        XCTAssertEqual(extracted[2].end, 34)
    }
    
}
